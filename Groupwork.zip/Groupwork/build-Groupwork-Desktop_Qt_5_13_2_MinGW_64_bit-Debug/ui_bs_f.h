/********************************************************************************
** Form generated from reading UI file 'bs_f.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_BS_F_H
#define UI_BS_F_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Bs_f
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Bs_f)
    {
        if (Bs_f->objectName().isEmpty())
            Bs_f->setObjectName(QString::fromUtf8("Bs_f"));
        Bs_f->resize(800, 600);
        menubar = new QMenuBar(Bs_f);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        Bs_f->setMenuBar(menubar);
        centralwidget = new QWidget(Bs_f);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Bs_f->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Bs_f);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Bs_f->setStatusBar(statusbar);

        retranslateUi(Bs_f);

        QMetaObject::connectSlotsByName(Bs_f);
    } // setupUi

    void retranslateUi(QMainWindow *Bs_f)
    {
        Bs_f->setWindowTitle(QCoreApplication::translate("Bs_f", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Bs_f: public Ui_Bs_f {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_BS_F_H
