/********************************************************************************
** Form generated from reading UI file 'zs_f.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ZS_F_H
#define UI_ZS_F_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Zs_f
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Zs_f)
    {
        if (Zs_f->objectName().isEmpty())
            Zs_f->setObjectName(QString::fromUtf8("Zs_f"));
        Zs_f->resize(800, 600);
        menubar = new QMenuBar(Zs_f);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        Zs_f->setMenuBar(menubar);
        centralwidget = new QWidget(Zs_f);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Zs_f->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Zs_f);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Zs_f->setStatusBar(statusbar);

        retranslateUi(Zs_f);

        QMetaObject::connectSlotsByName(Zs_f);
    } // setupUi

    void retranslateUi(QMainWindow *Zs_f)
    {
        Zs_f->setWindowTitle(QCoreApplication::translate("Zs_f", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Zs_f: public Ui_Zs_f {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ZS_F_H
