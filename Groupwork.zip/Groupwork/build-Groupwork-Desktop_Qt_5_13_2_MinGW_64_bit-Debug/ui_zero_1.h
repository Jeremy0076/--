/********************************************************************************
** Form generated from reading UI file 'zero_1.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ZERO_1_H
#define UI_ZERO_1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_zero_1
{
public:
    QWidget *centralwidget;
    QLineEdit *lineEdit;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *zero_1)
    {
        if (zero_1->objectName().isEmpty())
            zero_1->setObjectName(QString::fromUtf8("zero_1"));
        zero_1->resize(800, 600);
        centralwidget = new QWidget(zero_1);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        lineEdit = new QLineEdit(centralwidget);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(210, 250, 113, 21));
        zero_1->setCentralWidget(centralwidget);
        menubar = new QMenuBar(zero_1);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 800, 26));
        zero_1->setMenuBar(menubar);
        statusbar = new QStatusBar(zero_1);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        zero_1->setStatusBar(statusbar);

        retranslateUi(zero_1);

        QMetaObject::connectSlotsByName(zero_1);
    } // setupUi

    void retranslateUi(QMainWindow *zero_1)
    {
        zero_1->setWindowTitle(QCoreApplication::translate("zero_1", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class zero_1: public Ui_zero_1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ZERO_1_H
