/********************************************************************************
** Form generated from reading UI file 'zt_f.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ZT_F_H
#define UI_ZT_F_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Zt_f
{
public:
    QMenuBar *menubar;
    QWidget *centralwidget;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *Zt_f)
    {
        if (Zt_f->objectName().isEmpty())
            Zt_f->setObjectName(QString::fromUtf8("Zt_f"));
        Zt_f->resize(800, 600);
        menubar = new QMenuBar(Zt_f);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        Zt_f->setMenuBar(menubar);
        centralwidget = new QWidget(Zt_f);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        Zt_f->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(Zt_f);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        Zt_f->setStatusBar(statusbar);

        retranslateUi(Zt_f);

        QMetaObject::connectSlotsByName(Zt_f);
    } // setupUi

    void retranslateUi(QMainWindow *Zt_f)
    {
        Zt_f->setWindowTitle(QCoreApplication::translate("Zt_f", "MainWindow", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Zt_f: public Ui_Zt_f {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ZT_F_H
