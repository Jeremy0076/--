#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLabel>
#include <QMovie>
#include <QFont>
#include <QTextBrowser>
#include <QPainter>
#include <QTransform>
#include <QEvent>
#include <QResizeEvent>
#include <QSize>
#include <QPushButton>
#include <QTimer>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //设置背景色
    this->setStyleSheet("background-color:white;");
    //设置窗口标题
    setWindowTitle("概率论仿真软件");
    //设置的固定窗口大小
    setFixedSize(950,600);
    //设置窗口小图标
    this->setWindowIcon(QIcon(":/ImageQt/111.png"));
    //利用Qlabel显示gif图
    QMovie *movie = new QMovie(":/ImageQt/timg0GTPQDTG.gif");
    ui->label_gif0->setMovie(movie);
    //播放动图
    movie->start();

    //消除TextBrower边框
    ui->textBrowser_1->setStyleSheet("border-width:0;border-style:outset");
    ui->textBrowser_2->setStyleSheet("border-width:0;border-style:outset");


    //连接 离开和close
    connect(ui->pushButton_leave, &QPushButton::clicked, this, &QWidget::close);

    //实例化一个second_window
    second = new second_window;
    //连接 进入和打开second_window界面  自身隐藏

    connect(ui->pushButton_enter, &QPushButton::clicked,[=](){
        //设置延时0.3s
        QTimer::singleShot(300,this,[=](){
            this->hide();
            second->show();
        });
    });



}



MainWindow::~MainWindow()
{
    delete ui;
}

