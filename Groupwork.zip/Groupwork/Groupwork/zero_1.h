#ifndef ZERO_1_H
#define ZERO_1_H

#include <QMainWindow>

class zero_1 : public QMainWindow
{
    Q_OBJECT
public:
    explicit zero_1(QWidget *parent = nullptr);
    void  makeTable(zero_1 *zero1,double n);
    void  makeChart(QDockWidget *dockWidget,double p);
signals:
    //自定义信号
    //告诉主场景，点击了back
    void chooseBack();

public slots:

};

#endif // ZERO_1_H
