#ifndef JY_F_H
#define JY_F_H

#include <QMainWindow>

class Jy_f : public QMainWindow
{
    Q_OBJECT
public:
    explicit Jy_f(QWidget *parent = nullptr);
    void makedenisty(Jy_f *jyf,double a,double b);
    void makeChart(QDockWidget *dockWidget,double a,double b);
signals:
    //自定义信号
    //告诉主场景，点击了back
    void chooseBack();
public slots:
};

#endif // JY_F_H
