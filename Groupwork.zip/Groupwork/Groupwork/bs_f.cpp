#include "bs_f.h"
#include <mypushbutton.h>
#include <QDockWidget>
#include <QTableWidget>
#include <QToolBar>
#include <QTextBrowser>
#include <QFont>
#include <QLineEdit>
#include <QMessageBox>
#include <QChart>
#include <QBarSet>
#include <QBarSeries>
#include <QtCharts>
#include <cmath>
#include <algorithm>
#include <math.h>
#include <QScatterSeries>
#include <QSet>
Bs_f::Bs_f(QWidget *parent) : QMainWindow(parent)
{
    // 配置选择函数界面
    this->setFixedSize(950,600);
    setWindowTitle("概率论仿真软件");
    //设置窗口小图标
    this->setWindowIcon(QIcon(":/ImageQt/111.png"));
    myPushButton *backbtn = new myPushButton("","");
    //backbtn->setParent(this);
    backbtn->setText("BACK");
    backbtn->resize(125,50);
    //backbtn->move(this->width()-backbtn->width(),this->height()-backbtn->height());
    //工具栏
    QToolBar *toolBar = new QToolBar(this);
    addToolBar(Qt::RightToolBarArea,toolBar);
    toolBar->setFixedSize(backbtn->width(),this->height());
    backbtn->setParent(toolBar);
    backbtn->move(0,toolBar->height()-backbtn->height());
    toolBar->setStyleSheet("background:transparent;border:1px solid black");

    //工具栏中添加控件
    //1.添加确定按钮
    myPushButton *surebtn = new myPushButton("","");
    surebtn->setParent(toolBar);
    surebtn->setText("确定");
    surebtn->move(0,toolBar->height()-backbtn->height()-backbtn->height());
    surebtn->setFixedSize(backbtn->width(),backbtn->height());

    //调整按钮效果
    //点击效果
    connect(surebtn,&myPushButton::clicked,[=](){
       //弹起特效
        surebtn->zoom3();
        surebtn->zoom4();
    });
    connect(backbtn,&myPushButton::clicked,[=](){
       //弹起特效
        backbtn->zoom3();
        backbtn->zoom4();
    });

    //2.添加文字
    QTextBrowser *text = new QTextBrowser(toolBar);
    QFont myfont;
    myfont.setPixelSize(22);
    myfont.setBold(true);
    text->setFont(myfont);
    text->setText("泊松分布");
    text->move(0,0);
    text->setFixedSize(125,50);
    text->setAlignment(Qt::AlignCenter);

    //3.输入参数框
    QLineEdit *line = new QLineEdit(toolBar);
    line->move(12,100);
    line->setPlaceholderText("输入参数λ：");
    line->setClearButtonEnabled(true);
    QLineEdit *line1 = new QLineEdit(toolBar);
    line1->move(12,250);
    line1->setPlaceholderText("输入参数n：");
    line1->setClearButtonEnabled(true);
    //信号和槽
    connect(surebtn,&myPushButton::clicked,this,[=](){
        if(line->text().toDouble()>0&&line->text().toDouble()<=50){
            if(line1->text().toInt()>0){
                QMessageBox::information(this,"成功","图像生成");
                //函数图像的浮动窗口
                QDockWidget *dockWidget = new QDockWidget("函数图像",this);
                dockWidget->setFixedSize(825,600);
                addDockWidget(Qt::BottomDockWidgetArea,dockWidget);
                //调用生成分布率表格函数
                this->makeTable(this,line->text().toDouble(),line1->text().toInt());
                this->makeChart(dockWidget,line->text().toDouble(),line1->text().toInt());
            }else{
                QMessageBox::warning(this,"warning","输入不合法，请重新输入");
            }

        }else{
            QMessageBox::warning(this,"warning","输入不合法，请重新输入");
        }
    });
    //点击返回，实现
    connect(backbtn,&myPushButton::clicked,[=](){
        //主场景监听返回
        //自定义信号
        emit this->chooseBack();

    });
}


void Bs_f::makeTable(Bs_f *bsf, double p,int n){
    QTableWidget *table = new QTableWidget(2,n+2);
    table->setParent(bsf);
    table->move(25,100);
    for(int i=0;i<2;i++){
        table->setRowHeight(i,100);
    }
   /* for(int i=0;i<3;i++){
        table->setColumnWidth(i,800/50);
    }*/
    table->show();
    //准备内容
    QStringList XList;
    XList <<"X"<<"p";

    /*QList<QString> zeroList;
    QString s1 = QString::number(1-p);
    zeroList <<"0"<<s1;

    QList<QString> oneList;
    QString s2 = QString::number(p);
    oneList <<"1"<<s2;*/

    //设置表格内容
    for(int i=0; i<2;i++){
        int col=0;
        table->setItem(i,col++,new QTableWidgetItem(XList[i]));
       //table->setItem(i,col++,new QTableWidgetItem(zeroList[i]));
        //table->setItem(i,col++,new QTableWidgetItem(oneList[i]));
    }
    for(int i=1; i<n+2;i++){
        QString s1=QString::number(i-1);
        table->setItem(0,i,new QTableWidgetItem(s1));
        QString s2=QString::number(compute(i-1,p));
        table->setItem(1,i,new QTableWidgetItem(s2));
    }
}

double Bs_f::compute(int k,double p){
    double n1=1;
    for(int i=1;i<=k;i++){
        n1=n1*i;
    }
    double n2=1;
    for(int i=1;i<=k;i++){
        n2=n2*p;
    }
    double n3=1;
    n3=exp(-p);

    return n3*n2/n1;
}


void Bs_f::makeChart(QDockWidget *dockWidget,double p,int n){
    //创建一个集合
    //点状
     QScatterSeries *scatterSerise = new QScatterSeries();
     //设置离散点外貌
     scatterSerise->setMarkerShape(QScatterSeries::MarkerShapeCircle);
     scatterSerise->setBorderColor(QColor(21,100,255));
     scatterSerise->setBrush(QBrush(QColor(21,100,255)));
     scatterSerise->setMarkerSize(4);
     scatterSerise->setName("泊松分布");
     for(int i=0;i<=n;i++){
         scatterSerise->append(i,compute(i,p));
     }
     QChart *chart = new QChart();
     chart->addSeries(scatterSerise);
     chart->setTitle("泊松分布函数图像");
     chart->setAnimationOptions(QChart::SeriesAnimations);
     chart->show();

     //str<<"0"<<"1";
     //坐标轴 x
     QValueAxis *axisx = new QValueAxis;
     axisx->setRange(0,n);
     axisx->setTitleText("k");
     axisx->setLabelFormat("%.1f");
     axisx->setTickCount(n+1);
     axisx->setMinorTickCount(4);
     //坐标轴y
     QValueAxis *axisy = new QValueAxis;
     axisy->setRange(0,1);
     axisy->setTitleText("p");
     axisy->setLabelFormat("%.1f");
     axisy->setTickCount(10);
     axisy->setMinorTickCount(4);

    //点和轴联系
     scatterSerise->attachAxis(axisx);
     scatterSerise->attachAxis(axisy);
     chart->createDefaultAxes();
     chart->setAxisX(axisx,scatterSerise);
     chart->setAxisY(axisy,scatterSerise);
     chart->legend()->setVisible(false);
     chart->legend()->setAlignment(Qt::AlignBottom);
     chart->setBackgroundBrush(QBrush(QColor(248,251,255)));
     chart->resize(500,400);

     QChartView* chartView = new QChartView(chart);
     chartView->setRenderHint(QPainter::Antialiasing);
     chartView->setParent(dockWidget);
     chartView->show();
     chartView->move(50,50);
     chartView->setFixedSize(700,500);
     QHBoxLayout *layout = new QHBoxLayout();
     layout->setContentsMargins(0,0,0,0);
     layout->addWidget(chartView);
     setLayout(layout);
}
