#ifndef ZT_F_H
#define ZT_F_H

#include <QMainWindow>

class Zt_f : public QMainWindow
{
    Q_OBJECT
public:
    explicit Zt_f(QWidget *parent = nullptr);
    void makedenisty(Zt_f *ztf,double a,double b);
    double calculate(double a,double b,double pos);
    void makeChart(QDockWidget *dockWidget,double a,double b);
signals:
    //自定义信号
    //告诉主场景，点击了back
    void chooseBack();
public slots:
};

#endif // ZT_F_H
