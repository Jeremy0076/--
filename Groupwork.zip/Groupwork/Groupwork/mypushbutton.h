#ifndef MYPUSHBUTTON_H
#define MYPUSHBUTTON_H

#include <QPushButton>
#include <QString>
class myPushButton : public QPushButton
{
    Q_OBJECT
public:
   // explicit myPushButton(QWidget *parent = nullptr);

    //构造函数 参数1 正常显示的图片路径   参数2 按下后显示的图片路径
    myPushButton(QString normalImg, QString pressImg = "");

    //成员属性 保存用户传入的图片路径
    QString normalImgPath;
    QString pressImgPath;

    //弹跳特效 强
    void zoom1();//向下跳
    void zoom2();//向上跳
    //弱
    void zoom3();//下跳
    void zoom4();//上跳

signals:

public slots:
};

#endif // MYPUSHBUTTON_H
