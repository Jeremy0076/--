#include "second_window.h"
#include <QPainter>
#include <QDebug>
#include <QPushButton>
#include <mypushbutton.h>
#include <QTimer>
second_window::second_window(QWidget *parent) : QMainWindow(parent)
{
    // 配置选择函数界面
    this->setFixedSize(950,600);
    setWindowTitle("概率论仿真软件");
    //设置窗口小图标
    this->setWindowIcon(QIcon(":/ImageQt/111.png"));

    //创建选择函数按钮
    for(int i=0;i<6;i++){
        if(i==0){
            myPushButton *second_btn = new myPushButton(":/ImageQt/0-1book");
            second_btn->setParent(this);
            second_btn->move( 100 + i % 3 * 260, 100  + i / 3 * 240 );
            //点击效果
            connect(second_btn,&myPushButton::clicked,[=](){
               //弹起特效
                second_btn->zoom1();
                second_btn->zoom2();
            });
            //进入到0-1分布
            //实例化0-1界面
            zero1 = new zero_1 ;
            //监听返回按钮信号
            connect(zero1,&zero_1::chooseBack,this,[=](){
               zero1->hide();
               //重新显示主场景
               this->show();
            });
            connect(second_btn,&myPushButton::clicked,[=](){
                //延时进入
                QTimer::singleShot(350,this,[=](){
                    this->hide();
                    zero1 -> show();
                });
            });

        }else if(i==1){
            myPushButton *second_btn = new myPushButton(":/ImageQt/2xbook");
            second_btn->setParent(this);
            second_btn->move( 100 + i % 3 * 260, 100  + i / 3 * 240 );
            //点击效果
            connect(second_btn,&myPushButton::clicked,[=](){
               //弹起特效
                second_btn->zoom1();
                second_btn->zoom2();
            });
            twof = new Two_f ;
            //监听返回按钮信号
            connect(twof,&Two_f::chooseBack,this,[=](){
               twof->hide();
               //重新显示主场景
               this->show();
            });
            connect(second_btn,&myPushButton::clicked,[=](){
                //延时进入
                QTimer::singleShot(350,this,[=](){
                    this->hide();
                    twof -> show();
                });
            });
        }else if(i==2){
            myPushButton *second_btn = new myPushButton(":/ImageQt/bsbook");
            second_btn->setParent(this);
            second_btn->move( 100 + i % 3 * 260, 100  + i / 3 * 240 );
            //点击效果
            connect(second_btn,&myPushButton::clicked,[=](){
               //弹起特效
                second_btn->zoom1();
                second_btn->zoom2();
            });
            bsf = new Bs_f ;
            //监听返回按钮信号
            connect(bsf,&Bs_f::chooseBack,this,[=](){
               bsf->hide();
               //重新显示主场景
               this->show();
            });
            connect(second_btn,&myPushButton::clicked,[=](){
                //延时进入
                QTimer::singleShot(350,this,[=](){
                    this->hide();
                    bsf -> show();
                });
            });
        }else if(i==3){
            myPushButton *second_btn = new myPushButton(":/ImageQt/jybook");
            second_btn->setParent(this);
            second_btn->move( 100 + i % 3 * 260, 100  + i / 3 * 240 );
            //点击效果
            connect(second_btn,&myPushButton::clicked,[=](){
               //弹起特效
                second_btn->zoom1();
                second_btn->zoom2();
            });
            jyf = new Jy_f ;
            //监听返回按钮信号
            connect(jyf,&Jy_f::chooseBack,this,[=](){
              jyf->hide();
               //重新显示主场景
               this->show();
            });
            connect(second_btn,&myPushButton::clicked,[=](){
                //延时进入
                QTimer::singleShot(350,this,[=](){
                    this->hide();
                    jyf -> show();
                });
            });
        }else if(i==4){
            myPushButton *second_btn = new myPushButton(":/ImageQt/zsbook");
            second_btn->setParent(this);
            second_btn->move( 100 + i % 3 * 260, 100  + i / 3 * 240 );
            //点击效果
            connect(second_btn,&myPushButton::clicked,[=](){
               //弹起特效
                second_btn->zoom1();
                second_btn->zoom2();
            });
            zsf = new Zs_f ;
            //监听返回按钮信号
            connect(zsf,&Zs_f::chooseBack,this,[=](){
               zsf->hide();
               //重新显示主场景
               this->show();
            });
            connect(second_btn,&myPushButton::clicked,[=](){
                //延时进入
                QTimer::singleShot(350,this,[=](){
                    this->hide();
                    zsf -> show();
                });
            });
        }else if(i==5){
            myPushButton *second_btn = new myPushButton(":/ImageQt/ztbook");
            second_btn->setParent(this);
            second_btn->move( 100 + i % 3 * 260, 100  + i / 3 * 240 );
            //点击效果
            connect(second_btn,&myPushButton::clicked,[=](){
               //弹起特效
                second_btn->zoom1();
                second_btn->zoom2();
            });
            ztf = new Zt_f ;
            //监听返回按钮信号
            connect(ztf,&Zt_f::chooseBack,this,[=](){
               ztf->hide();
               //重新显示主场景
               this->show();
            });
            connect(second_btn,&myPushButton::clicked,[=](){
                //延时进入
                QTimer::singleShot(350,this,[=](){
                    this->hide();
                    ztf -> show();
                });
            });
        }
    }
}
//设置背景
void second_window::paintEvent(QPaintEvent *){
    QPainter painter(this);
    painter.drawPixmap(0,0,this->width(),this->height(),QPixmap(":/ImageQt/math1.jpg"));
}


