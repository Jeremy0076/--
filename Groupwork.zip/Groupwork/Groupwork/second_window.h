#ifndef SECOND_WINDOW_H
#define SECOND_WINDOW_H

#include <QMainWindow>
#include "zero_1.h"
#include "two_f.h"
#include "bs_f.h"
#include "jy_f.h"
#include "zs_f.h"
#include "zt_f.h"
class second_window : public QMainWindow
{
    Q_OBJECT
public:
    explicit second_window(QWidget *parent = nullptr);

    //绘图事件
    void paintEvent(QPaintEvent *);

    zero_1 * zero1 = NULL ;
    Two_f *twof = NULL;
    Bs_f *bsf = NULL;
    Jy_f *jyf = NULL;
    Zs_f *zsf = NULL;
    Zt_f *ztf = NULL;

signals:

public slots:
};

#endif // SECOND_WINDOW_H
