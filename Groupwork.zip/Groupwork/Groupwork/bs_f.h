#ifndef BS_F_H
#define BS_F_H

#include <QMainWindow>

class Bs_f : public QMainWindow
{
    Q_OBJECT
public:
    explicit Bs_f(QWidget *parent = nullptr);
    void makeTable(Bs_f *bsf, double p,int n);
    double compute(int k,double p);
    void makeChart(QDockWidget *dockWidget,double p,int n);
signals:
    //自定义信号
    //告诉主场景，点击了back
    void chooseBack();
public slots:
};

#endif // BS_F_H
