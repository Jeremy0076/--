#ifndef ZS_F_H
#define ZS_F_H

#include <QMainWindow>

class Zs_f : public QMainWindow
{
    Q_OBJECT
public:
    explicit Zs_f(QWidget *parent = nullptr);
    void makedenisty(Zs_f *zsf,double p);
    void makeChart(QDockWidget *dockWidget,double p);
signals:
    //自定义信号
    //告诉主场景，点击了back
    void chooseBack();
public slots:
};

#endif // ZS_F_H
