#ifndef TWO_F_H
#define TWO_F_H

#include <QMainWindow>

class Two_f : public QMainWindow
{
    Q_OBJECT
public:
    explicit Two_f(QWidget *parent = nullptr);
    void makeTable(Two_f *twof, double p,int n);
    double compute(int k,int n,double p);
    void makeChart(QDockWidget *dockWidget,double p,int n);
signals:
    //自定义信号
    //告诉主场景，点击了back
    void chooseBack();
public slots:
};

#endif // TWO_F_H
